PEACOCK WebView Fixed Project

Open this folder in Android Studio.
The supplied HTML is app/src/main/assets/index.html.
MainActivity loads it directly and handles Android Back correctly.

Build:
Build > Generate App Bundles or APKs > Generate APKs
